const express = require('express')
const {contract} = require('../contract')
const routes = express.Router()

routes.put('/report/addcomment',(req,res)=>{
    contract("INVOKE",["AddCommentsToReport",req.body.report_id,req.body.comment,req.body.ref_doctor],(err,payload)=>{
        console.log(payload)
        console.log('-------------------------')
        console.log(err)
        if (err){
            
            res.status(500).json(err)
        }
        else{
            res.status(200).json({
                "message": `Successfuly added comment to report ${req.body.report_id}`
            })
        }
    })
})

routes.post('/report/reftest',(req,res)=>{
    contract("INVOKE",["RefTest",req.body.report_id,req.body.name,req.body.ref_doctor,req.body.type_of_test],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json({
                "message": `Successfuly created test of type ${req.body.type_of_test}`,
                'test_id': payload.toString()
            })
        }
    })
})
routes.post('/report/reftreatment',(req,res)=>{
    contract("INVOKE",["RefTreatment",req.body.report_id,req.body.ref_doctor,req.body.name],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json({
                "message": `Successfuly created treatment of name ${req.body.name}`,
                'treatment_id': payload.toString()
            })
        }
    })
})

routes.post('/report/presdrugs',(req,res)=>{
    contract("INVOKE",["PrescribeDrugs",req.body.report_id,req.body.ref_doctor,req.body.drugs,req.body.doses],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json({
                "message": `Successfuly prescribe drugs`,
                'drug_id': payload.toString()
            })
        }
    })
})


routes.put('/treatment/addcomment',(req,res)=>{
    contract("INVOKE",["AddCommentsToTreatment",req.body.treatment_id,req.body.supervisor,req.body.comment],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json({
                "message": `Successfuly commented on treatment`
            })
        }
    })
})

routes.put('/treatment/addmediafile',(req,res)=>{
    contract("INVOKE",["AddMediaToTreatment",req.body.treatment_id,req.body.supervisor,req.body.no_of_mediafile],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json(JSON.parse(payload))
        }
    })
})

module.exports = routes