const express = require('express')
const {contract} = require('../contract')
routes = express.Router()

routes.get('/test',(req,res)=>{
    console.log(req.headers)
    contract("QUERY",["GetTest",req.body.test_id,req.body.requester],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json(JSON.parse(payload))
        }
    })
})
routes.get('/report',(req,res)=>{
    console.log(req.headers)
    contract("QUERY",["GetReport",req.body.report_id,req.body.requester],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json(JSON.parse(payload))
        }
    })
})

routes.get('/treatment',(req,res)=>{
    console.log(req.headers)
    contract("QUERY",["GetTreatment",req.body.treatment_id,req.body.requester],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json(JSON.parse(payload))
        }
    })
})

routes.get('/drug',(req,res)=>{
    console.log(req.headers)
    contract("QUERY",["GetDrugs",req.body.drug_id,req.body.requester],(err,payload)=>{
        if (err){
            res.status(500).json(err)
        }
        else{
            res.status(200).json(JSON.parse(payload))
        }
    })
})
module.exports = routes